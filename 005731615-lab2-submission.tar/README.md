## UID: 005731615
(IMPORTANT: Only replace the above numbers with your true UID, do not modify spacing and newlines, otherwise your tarfile might not be created correctly)

## You Spin Me Round Robin
Simulation for round robin scheduling given a workload and quantum length

## Building

Explain briefly how to build your program
Run the command "make"

## Running

Show an example run of your program, using at least two additional arguments, and what to expect
./rr processes.txt 3
You should expect two lines: 1 line for average wait time and 1 line for average response time

## Cleaning up

Explain briefly how to clean up all binary files
Run the command "make clean"